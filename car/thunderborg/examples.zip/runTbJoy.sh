#!/bin/bash
/home/pi/thunderborg/tbJoystick.py > /dev/null

