#!/bin/bash
/home/pi/diddyborgv2/diddy2Claw.py > /dev/null

