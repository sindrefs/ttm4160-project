#!/bin/bash
/home/pi/diddyborgv2/diddy2Joy.py > /dev/null

